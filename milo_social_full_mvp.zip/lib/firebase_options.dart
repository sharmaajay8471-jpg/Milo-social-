// Generated Firebase configuration placeholder.
// Run: dart pub global activate flutterfire_cli
// Then: flutterfire configure
// This file is intentionally kept free of real Firebase credentials.
class DefaultFirebaseOptions {
  static const currentPlatform = <String, dynamic>{};
}
