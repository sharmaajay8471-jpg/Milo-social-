import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  Future<void> createUser(String uid, String name, String username) =>
      db.collection('users').doc(uid).set({
        'name': name,
        'username': username,
        'followersCount': 0,
        'followingCount': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });

  Future<DocumentReference> createPost({
    required String uid,
    required String caption,
    required String mediaUrl,
    required String mediaType,
  }) => db.collection('posts').add({
    'uid': uid,
    'caption': caption,
    'mediaUrl': mediaUrl,
    'mediaType': mediaType,
    'likes': [],
    'createdAt': FieldValue.serverTimestamp(),
  });

  Stream<QuerySnapshot> feed() =>
      db.collection('posts').orderBy('createdAt', descending: true).snapshots();

  Stream<QuerySnapshot> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages')
          .orderBy('createdAt').snapshots();

  Future<void> sendMessage(String chatId, String uid, String text) =>
      db.collection('chats').doc(chatId).collection('messages').add({
        'senderId': uid,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });
}
