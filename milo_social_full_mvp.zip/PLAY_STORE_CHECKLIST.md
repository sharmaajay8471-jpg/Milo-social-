# Milo Play Store checklist

- Create Google Play Console developer account.
- Create Firebase project and enable Authentication, Firestore and Storage.
- Run `flutterfire configure` to generate Firebase configuration.
- Add app icon, privacy policy, support contact and screenshots.
- Complete Play Console Data Safety/content declarations.
- Set a unique Android applicationId/package name.
- Create and securely store an Android release signing key.
- Build with `flutter build appbundle --release`.
- Test through Play Console internal testing before production.
- Add report/block/mute, account deletion, privacy policy, terms and moderation before public launch.

## Voice/video calls
Use a dedicated WebRTC/RTC provider or your own WebRTC infrastructure. The Flutter app should receive short-lived call credentials/tokens from a trusted backend; provider secrets must never be shipped inside the app.
